<?php
// set the file name and create CSV file
$FileName = $resultsfile;
file_put_contents($FileName, $Content, FILE_APPEND);

// Get all current ParticipantIDs in results file
$results = array_map('str_getcsv', file($resultsfile));
array_walk($results, function(&$a) use ($results) {
  $a = array_combine($results[0], $a);
});
array_shift($results); # remove column header

// Get the ParticipantID column
$alreadyEntered = array_map(function($element) {
  return $element['ParticipantID'];
}, $results);

// Get the Wave column
$previousDataCollections = array_map(function($element) {
  return $element['Wave'];
}, $results);
?>
