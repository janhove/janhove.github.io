<?php
// Function for cleaning up data.
// Trims whitespace, removes slashes and converts special characters.
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

// Start PHP session
session_start();

// If the student assistant's username isn't available in the PHP session info,
// redirect the user to the login page (index.php).
if (empty($_SESSION['username'])) {
  header('Location: index.php');
  exit();
}

// Get the current date
$Date = date("Ymd-H:i:s");

// Get all current participant IDs
// First read in participants.csv
$file = 'Data/participants.csv';
$csv = array_map('str_getcsv', file($file));
array_walk($csv, function(&$a) use ($csv) {
  $a = array_combine($csv[0], $a);
});
array_shift($csv); # remove column header

// Get the ParticipantID column
$currentParticipantIDs = array_map(function($element) {
  return $element['ParticipantID'];
}, $csv);

$results = array_map('str_getcsv', file($resultsfile));
array_walk($results, function(&$a) use ($results) {
  $a = array_combine($results[0], $a);
});
array_shift($results); # remove column header

// Get the StudentID column
$alreadyEntered = array_map(function($element) {
  return $element['ParticipantID'];
}, $results);
?>
