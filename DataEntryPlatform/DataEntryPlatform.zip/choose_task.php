<?php
// Start the PHP session
session_start();

if (empty($_SESSION['username'])) {
  header('Location: index.php');
  exit();
}
?>

<!DOCTYPE html>
<html lang = "en">

<head>
  <meta charset="UTF-8">

  <script type="text/javascript" src="//code.jquery.com/jquery-1.8.3.js"></script>

  <link rel="stylesheet" type="text/css" href="stylesheet.css">

  <title>Choose form</title>


</head>

<body>

  <div class="outer">
    <div class="middle">
      <div class="inner">

        <div class="content">

          <p>Logged in as <?php echo $_SESSION['username']; ?>.
            Close the browser or click <a href="index.php">here</a> to log out.
          </p>
          
          <h1>Participant IDs</h1>

          <p><a href = "create_participant.php">Create new participant IDs.</a></p>

          <p><a href = "Data/participants.csv" download target = "_blank">Download participant IDs.</a></p>

          <h1>Task data</h1>

          <p><a href = "task_example.php">Enter example data.</a></p>

          <p><a href = "Data/taskexample.csv" download target = "_blank">Download example data.</a></p>

        </div> <!-- close content -->

      </div> <!-- close inner -->
    </div> <!-- close middle -->
  </div> <!-- close outer -->

</body>

</html>
