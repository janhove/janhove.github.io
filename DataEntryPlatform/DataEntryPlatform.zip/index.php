<?php
///////////////////////////////////////////////////////////////////////////////
// Data entry platform
// jan.vanhove@unifr.ch
// Last change: 2018-07-06
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Research assistants need to log in with their e-mail address and the 
// project password here. Change the e-mail addresses and the password below.
///////////////////////////////////////////////////////////////////////////////

// Start the PHP session
session_start();

// Reset session
$_SESSION = array();
session_unset();

// Array of possible e-mail addresses
$emails = array(
  "first.assistant@university.ch",
  "second.assistant@university.ch",
  "third.assistant@university.ch",
);

// Check log-in content
if (isset($_POST['login']) &&
    !empty($_POST['username']) &&
    !empty($_POST['password'])) {

      if (in_array($_POST['username'], $emails) &&
      		// change 'projectpassword' to your project password
          $_POST['password'] == 'projectpassword') {				 

            $_SESSION['valid'] = true;
            $_SESSION['username'] = $_POST['username'];

            header('Location: choose_task.php');
            exit();

      } else {
         $msg = 'Unknown e-mail address or wrong password.';
      }
   }
?>

<!DOCTYPE html>
<html lang = "en">

<head>
  <meta charset="UTF-8">

  <script type="text/javascript" src="//code.jquery.com/jquery-1.8.3.js"></script>

  <link rel="stylesheet" type="text/css" href="stylesheet.css">

  <title>Log-in</title>


</head>

<body>

  <div class="outer">
    <div class="middle">
      <div class="inner">

        <div class="content">

          <h1>Log-in</h1>

          <p>Log-in with your personal e-mail address and the project password.</p>

          <pre><?php echo $msg; ?></pre>

          <form class = "form-signin"
                autocomplete = "off"
                role = "form"
                action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
                method = "post">

          <p class="center">

           <input type = "text"
                  name = "username"
                  placeholder = "e-mail"
                  required autofocus><br />

           <input type = "password"
                  name = "password"
                  placeholder = "password" required><br />

           <button class = "button"
                   type = "submit"
                   name = "login">log-in</button>
           </p>

         </form>

        </div> <!-- close content -->

      </div> <!-- close inner -->
    </div> <!-- close middle -->
  </div> <!-- close outer -->

</body>

</html>
