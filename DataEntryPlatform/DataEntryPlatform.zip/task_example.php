<?php

///////////////////////////////////////////////////////////////////////////////
// Data entry platform
// jan.vanhove@unifr.ch
// Last change: 2018-07-06
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// This is an example of what a task-data entry form could look like.
// For our actual project, we used several such entry forms (different ones
// for each task); this example should giive you a sense of the possibilities.
///////////////////////////////////////////////////////////////////////////////

// Define the file in which this form's data are stored.
// This file won't be generated automatically, so you need to make
// sure there's a file in "Data" called "taskexample.csv" before
// entering data. This file should contain one row with column
// headers.
$resultsfile = 'Data/taskexample.csv';

// Some functions that we used for all task-data entry forms.
include 'php_header.php';

// Get the Wave column
$previousDataCollections = array_map(function($element) {
  return $element['Wave'];
}, $results);

// Process form upon submission
if(isset($_POST['submit'])){
  if(in_array(test_input($POST['ParticipantID']), $currentParticipantIDs)) {
  } else {
    ///////////////////////
    // Collect form data /
    ///////////////////////

    // ID of the research assistant who entered the data.
    // This isn't really necessary, but it doesn't hurt either.
    $Assistant = $_SESSION["username"];

    // Participant descriptives.
    $ParticipantID = test_input($_POST['ParticipantID']);
    
    // Wave of data collection
    $Wave = $_POST['Wave'];

    // Overwrite? (see below)
    $Overwrite = isset($_POST['Overwrite']) ? 1 : 0;    

    // Task data. 
    // These are just text fields that are cleaned up 
    // using the test_input function defined in php_header.php.
    $LLAMA = test_input($_POST['LLAMA']);
    $CorsiBlock = test_input($_POST['CorsiBlock']);

    // Corsi task completed?
    // (Uncheck if computer crashed mid-task.)
    // The expressions below evaluate to '1' if the checkbox 
    // was checked (default) and to '0' if it wasn't.
    $CorsiCompleted = isset($_POST['CorsiCompleted']) ? 1 : 0;
    
    // Questionnaire data.
    // This shows off some possibilities that are a bit more involved.
    // - NrBooks gets its data from a drop down menu.
    $NrBooks = $_POST['NrBooks'];
    
    // - 'NativeLanguages' gets its data from a series of checkboxes
    //   AND a free text field. Any number of checkboxes can be ticked
    //   to allow for multilingual participants; other languages named
    //   can be added using the text field. The 'NativeLanguages' entry
    //   becomes a string of all languages ticked or added using the text field.
    $NativeLanguages = $_POST['NativeLanguage'];
    $OtherNativeLanguages = test_input($_POST['NativeLanguageOthers']);
    if (empty($NativeLanguages)) {
      $NativeLanguages = $OtherNativeLanguages;
    } elseif ($OtherNativeLanguages == '') {
      $NativeLanguages = implode(', ', $NativeLanguages);
    } else {
      array_push($NativeLanguages, $OtherNativeLanguages);
      $NativeLanguages = implode(', ', $NativeLanguages);
    }
    
    // - 'DaZ' also gets its data from a series of checkboxes, but
    //   most of those can only be checked if the first checkbox
    //   was checked. This way you can accommodate filter questions.
    $DaZ = $_POST['DaZ'];
    if ($DaZ == "yes") {
      $DaZKindergarten1 = test_input($_POST['DaZKindergarten1']);
      $DaZKindergarten2 = test_input($_POST['DaZKindergarten2']);
      $DaZGrade1 = test_input($_POST['DaZGrade1']);
      $DaZGrade2 = test_input($_POST['DaZGrade2']);
    } else {
      $DaZKindergarten1 = 0;
      $DaZKindergarten2 = 0;
      $DaZGrade1 = 0;
      $DaZGrade2 = 0;
    }
    
    // Paste together new data
    $Content = "\"$Assistant\",$Date,\"$ParticipantID\",$Wave,$LLAMA,$CorsiBlock,$CorsiCompleted,\"$NativeLanguages\",\"$DaZKindergarten1\",\"$DaZKindergarten2\",\"$DaZGrade1\",\"$DaZGrade2\",$Overwrite\n";

		// Functions for updating the results file.
    include 'update_results.php';
  }
}
?>

<!DOCTYPE html>
<html lang = "en">

<head>
  <meta charset="UTF-8">
  <script type="text/javascript" src="//code.jquery.com/jquery-1.8.3.js"></script>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">


  <title>Data entry form (example)</title>

  <script type='text/javascript'>
  // Upon submission, this JavaScript checks 
  // (a) if the new ParticipantID was already entered via create_participant.php.
  //     If not, an error message pops up.
  // (b) 
  function ValidationEvent() {
    // Get participant IDs that exist in participants.csv
    var currentIDs = <?php echo json_encode($currentParticipantIDs); ?>;
    
    // New ID and data collection wave
    var newID = document.getElementById("ParticipantID").value;
    var newWave = document.getElementById("Wave").value;
    // Combine
    var newIDnewWave = newID.concat(newWave);
    
    // newID occurs in currentIDs, the id is known
    var idknown = currentIDs.indexOf(newID) != -1; // true vs. false
		
		// Get status of overwrite button
    var overwrite = document.getElementById("Overwrite").checked; // true vs. false

		// Get participant IDs and waves that exist in taskexample.csv
    var alreadyentered = <?php echo json_encode($alreadyEntered); ?>;
    var oldWave = <?php echo json_encode($previousDataCollections); ?>
    

    // Combine into one string
    var alreadyenteredthiswave = [];
    for(var i=0; i<alreadyentered.length; i++) {
    	alreadyenteredthiswave.push(alreadyentered[i].concat(oldWave[i]));
    }
    // var alreadyenteredthiswave = alreadyentered.concat(oldWave);
    console.log(alreadyenteredthiswave);
    
    // Check if data for this participant were already entered at this wave
    var presentindatabase = alreadyenteredthiswave.indexOf(newIDnewWave) != -1;

		// Throw errors if need be
    if(currentIDs.length < 1) {
    	alert("ParticipantID not in use. Please correct or create a new one.");
      return false;
    } else if (idknown == false) {
      alert("ParticipantID not in use. Please correct or create a new one.");
      return false;
    } else if(presentindatabase == true && overwrite == false) {
    	alert("Data for this ParticipantID and wave already entered. Please correct or overwrite.");
	    return false;
    } else {
      return true;
    }
  }
  
  // If the filter question 'DaZ' wasn't answered or was
  // answered in the negative, switch off the fields for
  // the follow-up questions.
  $(document).ready(function() {
  	toggleDaZYears();
	  $("#DaZ").change(function() { toggleDaZYears(); });
  });
	function toggleDaZYears()
	{
		if ($("#DaZ").val() == "yes") {
    	$('#DaZKindergarten1').attr('disabled',false);
    	$('#DaZKindergarten2').attr('disabled',false);
    	$('#DaZGrade1').attr('disabled',false);
    	$('#DaZGrade2').attr('disabled',false);
  	}
  else {
    	$('#DaZKindergarten1').attr('disabled',true);
    	$('#DaZKindergarten2').attr('disabled',true);
   	 	$('#DaZGrade1').attr('disabled',true);
    	$('#DaZGrade2').attr('disabled',true);
  	}
	}
  </script>


</head>

<body>



  <div class="outer">
    <div class="middle">
      <div class="inner">


        <p>
          Close your browser or
          click <a href="choose_task.php">here</a>
          if you want to stop entering data.
        </p>


        <h1>Example of a data entry form</h1>

        <?php
        if (empty($_SESSION["username"])) {
          header('Location: index.php');
        }
        ?>

        <form
        autocomplete = "off"
        method='post'
        onsubmit = "return ValidationEvent()"
        action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

        <p><label>ID: </label>
          <input type = "text"
          id = "ParticipantID"
          name = "ParticipantID"
          pattern="[4-5].[0-3][0-9].[0-9]{2}"
          title = "IDs should have the form [4-5].[0-3][0-9].[0-9][0-9]"
          placeholder = "0.12.34"
          required autofocus>
        </p>
        
        <p><label>Data collection wave: </label>
        	<select name="Wave" id="Wave">
      			<option selected value="1">T1</option>
      			<option value="2">T2</option>
      			<option value="3">T3</option>
      		</select>
      	</p>

        <h2>Task data</h2>

				<!-- On *most* browsers, you'll receive an error if you
				     don't enter an integer between 0 and 100. You can
				     use NA for missing data. -->
        <p>
          <label>LLAMA (proportion correct): </label>
          <input
          type = "text"
          name = "LLAMA"
          pattern="^([0-9]|[1-9][0-9]|100|NA)$"
          placeholder = "0 till 100, or NA"
          required>
        </p>

				<!-- Integer between 0 and 9, or NA. -->

        <p>
          <label>Corsi block span: </label>
          <input
          type = "text"
          name = "CorsiBlock"
          pattern="^([0-9]|NA)$"
          placeholder = "0 till 9, or NA"
          required>
        </p>

        <p><label>Corsi completed? </label>
          <input type = "checkbox"
          id = "CorsiCompleted"
          name = "CorsiCompleted"
          checked
          value = "1">
        </p>
        
        <hr />
        
        <h2>Questionnaire data</h2>
        
        <p>
        <label>Number of books: </label>
        	<select name="NrBooks" id="NrBooks">
      			<option selected value="NA">no response</option>
      			<option value="0-10">0-10</option>
      			<option value="11-25">11-25</option>
      			<option value="26-100">26-100</option>
      			<option value="101-200">101-200</option>
      			<option value="201-500">201-500</option>
      			<option value="500+">500+</option>
      		</select>
      	</p>
      	
      	<hr />

        <p><label for = "NLGerman">Native language German: </label> 
        <input type="checkbox" name="NativeLanguage[]" id="NLGerman" value="German" checked/></p>
        
        <p><label for = "NLFrench">Native language French: </label> 
        <input type="checkbox" name="NativeLanguage[]" id="NLFrench" value="French"/></p>
        
        <p><label for = "NLItalian">Native language Italian: </label> 
        <input type="checkbox" name="NativeLanguage[]" id="NLItalian" value="Italian"/></p>
        
        <p><label for = "NLRomansh">Native language Romansh: </label> 
        <input type="checkbox" name="NativeLanguage[]" id="NLRomansh" value="Romansh"/></p>

				<p><label for = "NLEnglish">Native language English: </label> 
				<input type="checkbox" name="NativeLanguage[]" id="NLEnglish" value="English"/></p>
				
				<p><label for = "NLAlbanian">Native language Albanian: </label> 
				<input type="checkbox" name="NativeLanguage[]" id="NLAlbanian" value="Albanian"/></p>
				
				<p><label for = "NLPortuguese">Native language Portuguese: </label> 
				<input type="checkbox" name="NativeLanguage[]" id="NLPortuguese" value="Portuguese"/></p>

				<p><label>Other native languages: </label> 
				<input type="text" name="NativeLanguageOthers" id="NativeLanguageOthers" placeholder = "separate entries with commas"/></p>

        <hr />
        
        <p>
          <label>DaZ? </label>
          <select name = "DaZ" id = "DaZ">
          	<option selected value = "no">no</option>
          	<option value = "yes">yes</option>
          	<option value = "NA">no response</option>
          </select>
        </p>

				<p>
  				<label>DaZ in 1st kindergarten? </label>
  				<input type = "text"
  							 pattern = "[01]|NA"
  							 name = "DaZKindergarten1"
  							 id = "DaZKindergarten1"
  							 placeholder = "0-1, or NA"
  							 title = "0-1, or NA"
  							 required>
  			</p>
  			
  			<p>
  				<label>DaZ in 2nd kindergarten? </label>
  				<input type = "text"
  							 pattern = "[01]|NA"
  							 name = "DaZKindergarten2"
  							 id = "DaZKindergarten2"
  							 placeholder = "0-1, or NA"
  							 title = "0-1, or NA"
  							 required>
  			</p>
  			
  			<p>
  				<label>DaZ in 1st grade? </label>
  				<input type = "text"
  							 pattern = "[01]|NA"
  							 name = "DaZGrade1"
  							 id = "DaZGrade1"
  							 placeholder = "0-1, or NA"
  							 title = "0-1, or NA"
  							 required>
  			</p>
  			
  			<p>
  				<label>DaZ in 2nd grade? </label>
  				<input type = "text"
  							 pattern = "[01]|NA"
  							 name = "DaZGrade2"
  							 id = "DaZGrade2"
  							 placeholder = "0-1, or NA"
  							 title = "0-1, or NA"
  							 required>
  			</p>
  			
  			<hr />  			

				<p><label>Correct existing entry? </label>
          <input type = "checkbox"
          id = "Overwrite"
          name = "Overwrite"
          value = "1">
        </p>


        <p>
          <label></label>
          <input type="submit" name ="submit" value="eintragen" class = "button" />
        </p>

      </form>
    </div>
  </div>
</div>
</body>
</html>
