<?php
///////////////////////////////////////////////////////////////////////////////
// Data entry platform
// jan.vanhove@unifr.ch
// Last change: 2018-07-06
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Use this form to create new participant IDs and associated information.
// You can only enter data for participants in the other form if their
// IDs have been created here first. This makes it less likely that data are
// associated with participant IDs that don't actually exist.
///////////////////////////////////////////////////////////////////////////////

// Function for cleaning up data.
// Trims whitespace, removes slashes and converts special characters.
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

// Start PHP session
session_start();

// If the student assistant's username isn't available in the PHP session info,
// redirect the user to the login page (index.php).
if (empty($_SESSION['username'])) {
  header('Location: index.php');
  exit();
}

// Get the current date
$Date = date("Ymd-H:i:s");

// Get all current participant IDs
// First read in participants.csv
$file = 'Data/participants.csv';
$csv = array_map('str_getcsv', file($file));
array_walk($csv, function(&$a) use ($csv) {
  $a = array_combine($csv[0], $a);
});
array_shift($csv); # remove column header

// Get the ParticipantID column
$currentParticipantIDs = array_map(function($element) {
  return $element['ParticipantID'];
}, $csv);

// Process form upon submission
if(isset($_POST['submit'])){
  if(in_array(test_input($_POST['ParticipantID']), $currentParticipantIDs)) {
    
    // Don't do anything if ParticipantID already occurs in database.
    // The JavaScript snippet below (ValidationEvent()) takes care of this.
} else {
  
    ///////////////////////
    // Collect form data //
    ///////////////////////

    // ID of the research assistant who entered the data.
    // This isn't really necessary, but it doesn't hurt either.
		$Assistant = $_SESSION["username"];

    // Participant descriptives.
		$ParticipantID = test_input($_POST['ParticipantID']);
		$Grade = test_input($_POST['Grade']);
		$Comments = test_input($_POST['Comments']);

    // Overwrite (see below)?
		$Overwrite = isset($_POST['Overwrite']) ? 1 : 0;

    // Paste together new data
		$Content = "\"$Assistant\",$Date,\"$ParticipantID\",$Grade,\"$Comments\",$Overwrite\n";

    // Set the file name and create CSV file
		$FileName = "participants.csv";
		file_put_contents("Data/".$FileName, $Content, FILE_APPEND);

    // Update currentStudentIDs
    // Get all current ParticipantIDs
    // First read in vpn.csv
		$file = 'Data/participants.csv';
		$csv = array_map('str_getcsv', file($file));
		array_walk($csv, function(&$a) use ($csv) {
			$a = array_combine($csv[0], $a);
		});
		array_shift($csv); # remove column header

    // Get the ParticipantID column
		$currentParticipantIDs = array_map(function($element) {
			return $element['ParticipantID'];
		}, $csv);
	}
}
?>

<!DOCTYPE html>
<html lang = "en">

<head>
  <meta charset="UTF-8">
  <script type="text/javascript" src="//code.jquery.com/jquery-1.8.3.js"></script>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">

  <title>Create participant ID</title>

  <script type='text/javascript'>
  // This function generates a pop-up window is the new participant ID
  // already occurs in the dataset. It's possible to overwrite the old
  // participant ID if the checkbox 'Correct existing entry' is checked. This isn't
  // useful here, but it can be useful if you add more data on this page.
 	function ValidationEvent() {
 		var currentIDs = <?php echo json_encode($currentParticipantIDs); ?>;
    var newID = document.getElementById("ParticipantID").value;
    var overwrite = document.getElementById("Overwrite").checked; // true vs. false
    var alreadypresent = currentIDs.indexOf(newID) != -1;         // true vs. false
    
    if (overwrite == false && alreadypresent == true) {
    	alert("ParticipantID already used. Check 'Correct existing entry' to correct the old entry.");
    	return false;
    } else {
			return true;
		}
	}
  </script>

</head>

<body>



  <div class="outer">
    <div class="middle">
      <div class="inner">

        <p>
          Close your browser or
          click <a href="choose_task.php">here</a>
          if you want to stop entering data.
        </p>


        <h1>Create participant ID</h1>

        <form
        autocomplete = "off"
        method='post'
        onsubmit = "return ValidationEvent()"
        action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        
        <!-- Enter the ParticipantID.
        For this project, the ID had to consist of one number (4 or 5),
        followed by a dot, then another number between 01 and 39,
        followed by another dot, and then another number between 01 and 99. 
        Using regular expressions, you can set your own formal criteria
        in the 'pattern' slot in order to reduce the chances that
        invalid participant IDs are entered. -->

        <p><label>ID: </label>
          <input type = "text"
          id = "ParticipantID"
          name = "ParticipantID"
          pattern="[4-5].[0-3][0-9].[0-9]{2}"
          title = "IDs have the form [4-5].[0-3][0-9].[0-9][0-9]"
          onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Wrong ID form.' : ''); if(this.checkValidity()) form.Level.pattern = this.value.charAt(0);"
          placeholder = "0.12.34"
          required autofocus>
        </p>
        
        <!-- Enter the participants' grade (either 4 or 5).
        This is another failsafe: If the participant's grade
        doesn't match the first number in their ID, the form
        will throw an error. -->

        <p><label>Grade: </label>
          <input type = "text"
          name = "Level"
          pattern = "[4-5]"
          placeholder = "4, 5"
          onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Grade doesn't agree with ParticipantID' : '');"
          required>
        </p>
        
        <p><label>Comments (optional): </label>
        	<textarea cols = "28" rows = "5" name = "Comment"></textarea>
        </p>

        <hr />
        
        <!-- This is useless here, but if you want to use this page
        to enter more data about the participants, it can be useful. -->

        <p><label>Correct existing entry? </label>
          <input type = "checkbox"
          id = "Overwrite"
          name = "Overwrite"
          value = "1">
        </p>

        <p>
          <label></label>
          <input type="submit" name ="submit" value="submit" class = "button" />
        </p>

      </form>
    </div>
  </div>
</div>
</body>
</html>
